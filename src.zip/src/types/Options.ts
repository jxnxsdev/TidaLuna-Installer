export type Options = {
    action: "uninstall" | "install";
    downloadUrl?: string;
    overwritePath?: string;
}