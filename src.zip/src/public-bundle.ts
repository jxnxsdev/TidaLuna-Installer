
// This file is auto-generated
export const publicAssets: Record<string, string> = {};
